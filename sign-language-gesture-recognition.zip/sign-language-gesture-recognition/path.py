import os


d = os.getcwd()
print(d)